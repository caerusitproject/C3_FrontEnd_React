import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { useTheme } from "../../context/ThemeContext";
import { useDispatch, useSelector } from "react-redux";

import { toggleSidebar } from "../../store/slices/loginSlice";
import TopNavbar from "./TopNavbar";
import SideNavbar from "./SideNavbar";
import Footer from "./Footer";
import { GlobalAlert } from "../../Components/ui/Alert/GlobalAlert";

export default function AppLayout() {
  const theme = useTheme();
  const collapsed = useSelector((state) => state.login.collapsed);
  const dispatch = useDispatch();
  const [width, setWidth] = useState(window.innerWidth);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleResize = () => {
      setWidth(window.innerWidth);

      // close mobile drawer on desktop/tablet
      if (window.innerWidth >= 768) {
        setMobileOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const isMobile = width < 768;

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100vh",
        background: theme.foundation.applicationBackground,
        transition: "background 0.3s ease",
        overflow: "hidden",
      }}
    >
      <GlobalAlert />

      {/* TOP NAVBAR */}
      <TopNavbar
        isMobile={isMobile}
        isTablet={width >= 768 && width < 1024}
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        onMobileToggle={() => {
          if (width >= 768 && width < 1024) {
            dispatch(toggleSidebar());
          } else {
            setMobileOpen((prev) => !prev);
          }
        }}
      />

      {/* BODY */}
      <div
        style={{
          display: "flex",
          flex: 1,
          overflow: "hidden",
          position: "relative",
        }}
      >
        {/* MOBILE OVERLAY */}
        {isMobile && mobileOpen && (
          <div
            onClick={() => setMobileOpen(false)}
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(0,0,0,0.45)",
              zIndex: 9998,
            }}
          />
        )}

        {/* SIDEBAR */}
        <aside
          style={{
            position: isMobile ? "fixed" : "relative",
            top: 0,
            left: 0,
            height: "100%",
            width:
              width >= 768 && width < 1024
                ? collapsed
                  ? "72px"
                  : "256px"
                : "256px",
            background: theme.foundation.surfaceBackground,
            borderRight: `1px solid ${theme.foundation.borderColor}`,
            zIndex: 9999,
            flexShrink: 0,
            overflow: "hidden",

            transform: isMobile
              ? mobileOpen
                ? "translateX(0)"
                : "translateX(-100%)"
              : "translateX(0)",

            transition:
              "width 0.3s ease, transform 0.3s ease, background 0.3s ease",

            boxShadow:
              isMobile && mobileOpen ? "4px 0 24px rgba(0,0,0,0.18)" : "none",
          }}
        >
          <SideNavbar
            collapsed={
              width >= 768 && width < 1024 ? collapsed : isMobile && !mobileOpen
            }
            isMobile={isMobile}
            isTablet={width >= 768 && width < 1024}
            onNavClick={() => setMobileOpen(false)}
            onToggleMobile={() => setMobileOpen(false)}
          />
        </aside>

        {/* RIGHT CONTENT AREA */}
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            background: theme.foundation.applicationBackground,
          }}
        >
          {/* MAIN */}
          <main
            style={{
              flex: 1,
              overflowY: "auto",
              background: theme.foundation.applicationBackground,
              transition: "background 0.3s ease",
            }}
          >
            <Outlet />
          </main>

          {/* FOOTER */}
          <Footer />
        </div>
      </div>
    </div>
  );
}
