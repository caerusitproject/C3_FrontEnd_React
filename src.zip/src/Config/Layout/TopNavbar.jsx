import React, { useState, useRef, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import {
  useTheme,
  useThemeContext,
} from "../../context/ThemeContext";
import { logout } from "../../store/slices/loginSlice";

const THEME_LABELS = {
  lightOrange: "Light Orange",
  lightOliveGreen: "Light Olive Green",
  darkGreen: "Dark Green",
};

export default function TopNavbar({
  isMobile,
  mobileOpen,
  onMobileToggle,
  isTablet,
    collapsed,

}) {
  const theme = useTheme();
  const { themeId } = useThemeContext();

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { loggedInUser } = useSelector((state) => state.login);

  const [profileOpen, setProfileOpen] = useState(false);

  const profileRef = useRef(null);

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login", { replace: true });
  };

  // outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        profileRef.current &&
        !profileRef.current.contains(event.target)
      ) {
        setProfileOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener(
        "mousedown",
        handleClickOutside
      );
    };
  }, []);

  return (
    <>
      <header
        style={{
          height: "60px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 20px",
          background: theme.foundation.surfaceBackground,
          borderBottom: `1px solid ${theme.foundation.borderColor}`,
          flexShrink: 0,
          zIndex: 10,
        }}
      >
        {/* LEFT */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "12px",
          }}
        >
          {/* MOBILE HAMBURGER */}
         {(
  (isMobile && !mobileOpen) ||
  (isTablet && collapsed)
) && (
            <button
              onClick={onMobileToggle}
              style={{
                width: "36px",
                height: "36px",
                border: "none",
                background: "transparent",
                cursor: "pointer",
                fontSize: "22px",
                color: theme.typography.bodyText,
              }}
            >
              ☰
            </button>
          )}

          {/* LOGO */}
          <div
            style={{
              width: "32px",
              height: "32px",
              borderRadius: "8px",
              background: theme.foundation.primaryColor,
            }}
          />
        </div>

        {/* RIGHT */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "10px",
          }}
        >
          {/* PROFILE */}
          <div
            ref={profileRef}
            style={{ position: "relative" }}
          >
            <div
              onClick={() =>
                setProfileOpen((prev) => !prev)
              }
              style={{
                width: "34px",
                height: "34px",
                borderRadius: "50%",
                background:
                  theme.foundation.primaryColor,
                color: "white",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontWeight: "600",
                cursor: "pointer",
              }}
            >
              {loggedInUser?.name?.[0]?.toUpperCase() ??
                "U"}
            </div>

            {profileOpen && (
              <>
                {/* BACKDROP */}
                <div
                  onClick={() =>
                    setProfileOpen(false)
                  }
                  style={{
                    position: "fixed",
                    top: 0,
                    left: 0,
                    width: "100vw",
                    height: "100vh",
                    background: "rgba(0,0,0,0.15)",
                    zIndex: 998,
                  }}
                />

                {/* PROFILE CARD */}
                <div
                  style={{
                    position: "absolute",
                    right: 0,
                    top: "45px",
                    width: "260px",
                    background:
                      theme.foundation.surfaceBackground,
                    border: `1px solid ${theme.foundation.borderColor}`,
                    borderRadius: "12px",
                    boxShadow:
                      "0 10px 30px rgba(0,0,0,0.15)",
                    padding: "12px",
                    zIndex: 999,
                  }}
                >
                  <div style={{ fontWeight: 600 }}>
                    {loggedInUser?.name}
                  </div>

                  <div
                    style={{
                      fontSize: "12px",
                      opacity: 0.7,
                    }}
                  >
                    {loggedInUser?.email}
                  </div>

                  <div
                    style={{
                      margin: "10px 0",
                      fontSize: "12px",
                    }}
                  >
                    🟢 Available
                  </div>

                  <button
                    style={{
                      width: "100%",
                      padding: "8px",
                      marginBottom: "8px",
                      borderRadius: "8px",
                      border: `1px solid ${theme.foundation.borderColor}`,
                      background: "transparent",
                      cursor: "pointer",
                    }}
                  >
                    View Profile
                  </button>

                  <button
                    onClick={handleLogout}
                    style={{
                      width: "100%",
                      padding: "8px",
                      borderRadius: "8px",
                      border: "none",
                      background: "#e53935",
                      color: "white",
                      cursor: "pointer",
                    }}
                  >
                    Logout
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </header>
    </>
  );
}