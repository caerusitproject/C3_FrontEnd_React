import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import { useTheme, useGlobalTokens } from "../../context/ThemeContext";

import { logout, toggleSidebar } from "../../store/slices/loginSlice";

const MODULE_ICONS = {
  Home: (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  ),
};

const DEFAULT_ICON = (
  <svg
    width="18"
    height="18"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="12" cy="12" r="10" />
    <line x1="12" y1="8" x2="12" y2="12" />
    <line x1="12" y1="16" x2="12.01" y2="16" />
  </svg>
);

const DEFAULT_MENUS = [
  {
    moduleName: "Home",
    url: "/home",
  },
];

export default function SideNavbar({
  collapsed,
  onNavClick,
  isMobile,
  isTablet,
  onToggleMobile,
}) {
  const theme = useTheme();

  const globalTokens = useGlobalTokens();

  const dispatch = useDispatch();

  const navigate = useNavigate();

  const menus = useSelector((state) => state.login.menus);

  const loggedInUser = useSelector((state) => state.login.loggedInUser);

  const menuList = menus?.length > 0 ? menus : DEFAULT_MENUS;

  const handleLogout = () => {
    dispatch(logout());

    navigate("/login", {
      replace: true,
    });
  };

  return (
    <nav
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        padding: "12px 8px",
        gap: "4px",
        overflowX: "hidden",
        overflowY: "auto",
      }}
    >
      {/* USER HEADER */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "4px 4px 12px",
          borderBottom: `1px solid ${theme.foundation.borderColor}`,
          marginBottom: "4px",
          gap: "8px",
          minHeight: "52px",
        }}
      >
        {/* USER INFO */}
        {!collapsed && (
          <div
            style={{
              flex: 1,
              minWidth: 0,
            }}
          >
            <div
              style={{
                fontSize: "13px",
                fontWeight: "600",
                color: theme.typography.bodyText,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {loggedInUser?.employeeName || loggedInUser?.name || "User"}
            </div>

            <div
              style={{
                fontSize: "11px",
                color: theme.typography.helperText,
                whiteSpace: "nowrap",
                marginTop: "1px",
              }}
            >
              {loggedInUser?.employeeId || ""}
            </div>
          </div>
        )}

        {/* MOBILE CLOSE BUTTON */}
        {(isMobile || isTablet) && !collapsed && (
          <button
            onClick={() => {
              if (isMobile) {
                onToggleMobile?.();
              } else if (isTablet) {
                dispatch(toggleSidebar());
              }
            }}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
              width: "32px",
              height: "32px",
              borderRadius: "8px",
              border: "none",
              background: "transparent",
              cursor: "pointer",
              color: theme.typography.bodyText,
              fontSize: "22px",
            }}
          >
            ☰
          </button>
        )}
      </div>

      {/* MENUS */}
      {menuList.map((item) => (
        <NavLink
          key={item.url}
          to={item.url}
          onClick={onNavClick}
          style={({ isActive }) => ({
            display: "flex",
            alignItems: "center",
            gap: "10px",
            padding: "10px 12px",
            borderRadius: "10px",
            textDecoration: "none",
            fontWeight: "500",
            fontSize: "14px",
            whiteSpace: "nowrap",
            transition: "all 0.2s ease",
            color: isActive
              ? theme.foundation.primaryColor
              : theme.typography.bodyText,
            background: isActive
              ? theme.foundation.secondaryColor
              : "transparent",
          })}
        >
          <span style={{ flexShrink: 0 }}>
            {MODULE_ICONS[item.moduleName] ?? DEFAULT_ICON}
          </span>

          {!collapsed && (
            <span
              style={{
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {item.moduleName}
            </span>
          )}
        </NavLink>
      ))}

      {/* SPACER */}
      <div style={{ flex: 1 }} />

      {/* LOGOUT */}
      <button
        onClick={handleLogout}
        style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          padding: "10px 12px",
          borderRadius: "10px",
          border: "none",
          background: "transparent",
          cursor: "pointer",
          fontWeight: "500",
          fontSize: "14px",
          whiteSpace: "nowrap",
          width: "100%",
          color: theme.typography.bodyText,
          transition: "all 0.2s ease",
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.background = globalTokens.state.errorBackground;

          e.currentTarget.style.color = globalTokens.state.errorText;
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.background = "transparent";

          e.currentTarget.style.color = theme.typography.bodyText;
        }}
      >
        <span style={{ flexShrink: 0 }}>
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4" />
            <polyline points="16 17 21 12 16 7" />
            <line x1="21" y1="12" x2="9" y2="12" />
          </svg>
        </span>

        {!collapsed && <span>Logout</span>}
      </button>
    </nav>
  );
}
